import torch
import torch.nn as nn
import math
import matplotlib.pyplot as plt
from pathlib import Path
from datetime import datetime
from PIL import Image
import numpy as np


# FFN
def FeedForward(dim, mult=4):
    inner_dim = int(dim * mult)
    return nn.Sequential(
        nn.LayerNorm(dim),
        nn.Linear(dim, inner_dim, bias=False),
        nn.GELU(),
        nn.Linear(inner_dim, dim, bias=False),
    )


def reshape_tensor(x, heads):
    bs, length, width = x.shape
    # (bs, length, width) --> (bs, length, n_heads, dim_per_head)
    x = x.view(bs, length, heads, -1)
    # (bs, length, n_heads, dim_per_head) --> (bs, n_heads, length, dim_per_head)
    x = x.transpose(1, 2)
    # (bs, n_heads, length, dim_per_head) --> (bs*n_heads, length, dim_per_head)
    x = x.reshape(bs, heads, length, -1)
    return x


# import matplotlib.pyplot as plt
# def save_attention_weights_as_image(weight, file_path="attention_weights.png"):
#     # Save the attention weights as an image
#     plt.figure(figsize=(10, 10))
#     plt.imshow(weight.detach().cpu().numpy(), cmap='viridis')
#     plt.colorbar()
#     plt.title("Attention Weights")
#     plt.xlabel("Key Positions")
#     plt.ylabel("Query Positions")
#     plt.savefig(file_path)
#     plt.close()

class PerceiverAttentionCA(nn.Module):
    def __init__(self, *, dim=3072, dim_head=128, heads=16, kv_dim=2048):
        super().__init__()
        self.scale = dim_head ** -0.5
        self.dim_head = dim_head
        self.heads = heads
        inner_dim = dim_head * heads

        self.norm1 = nn.LayerNorm(dim if kv_dim is None else kv_dim)
        self.norm2 = nn.LayerNorm(dim)

        self.to_q = nn.Linear(dim, inner_dim, bias=False)
        self.to_kv = nn.Linear(dim if kv_dim is None else kv_dim, inner_dim * 2, bias=False)
        self.to_out = nn.Linear(inner_dim, dim, bias=False)

    def forward(self, x, latents):  # x是id特征，latents是生成的图像特征
        """
        Args:
            x (torch.Tensor): image features
                shape (b, n1, D)
            latent (torch.Tensor): latent features
                shape (b, n2, D)
        """
        # import pdb;
        # pdb.set_trace()
        x = self.norm1(x)  # x 1,32,2048
        latents = self.norm2(latents)  # 4,2304,3072

        b, seq_len, _ = latents.shape

        q = self.to_q(latents)  # 4,2304,2048
        k, v = self.to_kv(x).chunk(2, dim=-1)  # 1,32,2048,chunk拆成两部分

        q = reshape_tensor(q, self.heads)  # 4,16,2304,128
        k = reshape_tensor(k, self.heads)  # 1,16,32,128
        v = reshape_tensor(v, self.heads)  # 1,16,32,128

        # attention
        scale = 1 / math.sqrt(math.sqrt(self.dim_head))  # 0.2973
        weight = (q * scale) @ (k * scale).transpose(-2,
                                                     -1)  # More stable with f16 than dividing afterwards 4,16,2304,32
        weight = torch.softmax(weight.float(), dim=-1).type(weight.dtype)  # 4,16,2304,32
        out = weight @ v  # 1,16,32,128

        # Save the attention weights as an image
        # weight = weight.to(torch.float32);
        # save_attention_weights_as_image(weight[0]) # 16,2304,32

        out = out.permute(0, 2, 1, 3).reshape(b, seq_len, -1)

        return self.to_out(out)


# 注意力可视化保存函数
def save_attention_weights_as_image(attention_weights, filename="attention_map"):
    """
    保存注意力权重矩阵为图像
    输入形状: (num_heads, query_len, key_len)
    """
    # 创建保存目录
    file = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = Path(f"/home/gdli7/Blade/results/pulid/attention_maps/{file}")
    save_dir.mkdir(exist_ok=True, parents=True)

    # 转换张量到CPU并解除梯度
    attention_weights = attention_weights[0]
    attention_weights = attention_weights.detach().cpu().float()

    # 可视化每个注意力头
    num_heads = attention_weights.shape[0]

    for head_idx in range(num_heads):
        plt.figure(figsize=(12, 8))

        # 获取单个头的注意力权重
        head_weights = attention_weights[head_idx]

        # 显示注意力矩阵
        plt.imshow(head_weights, cmap='viridis', aspect='auto')
        plt.colorbar()
        plt.title(f'Attention Head {head_idx}')
        plt.xlabel("Key Positions")
        plt.ylabel("Query Positions")

        # 保存图像
        plt.savefig(save_dir / f"{filename}_head{head_idx}.png", bbox_inches='tight')
        plt.close()


def save_attention_weights_as_image_v1(attentions, filename="attention_map"):
    # 这块还是有很多难点了，导致我暂时没有很好的思路来做这个事情
    # attentions:4,16,2304,32
    nh = attentions.shape[1]
    # import pdb;
    # pdb.set_trace()
    # attentions = attentions[0, :, 0, 1:].reshape(nh, -1)
    attentions = attentions[0, :, :, 0].reshape(nh, -1)
    heads, seq_len = attentions.shape

    # attentions = attentions.reshape(nh, int(seq_len ** 0.5), int(seq_len ** 0.5)).detach().cpu().numpy()
    attentions = attentions.to(torch.float32).reshape(nh, int(seq_len ** 0.5),
                                                      int(seq_len ** 0.5)).detach().cpu().numpy()
    height, width = int(seq_len ** 0.5), int(seq_len ** 0.5)
    # height, width = 256,256
    # img = np.zeros((height, width), dtype=np.uint8)
    # img = Image.fromarray(img)
    plot_attention(attentions)


def plot_attention(attention):
    # 创建保存目录
    file = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = Path(f"/home/gdli7/Blade/results/pulid/attention_maps_v1/{file}")
    save_dir.mkdir(exist_ok=True, parents=True)
    n_heads = attention.shape[0]

    plt.figure(figsize=(10, 10))
    text = ["Head Mean"]
    for i, fig in enumerate([np.mean(attention, 0)]):
        plt.subplot(1, 1, i + 1)
        plt.imshow(fig, cmap='inferno')
        plt.title(text[i])
    plt.show()
    # 保存图像
    plt.savefig(save_dir / f"head.png", bbox_inches='tight')
    plt.close()

    plt.figure(figsize=(10, 10))
    for i in range(n_heads):
        plt.subplot((n_heads + 2) // 3, 3, i + 1)
        plt.imshow(attention[i], cmap='inferno')
        plt.title(f"Head n: {i + 1}")
    plt.tight_layout()
    plt.show()
    # 保存图像
    plt.savefig(save_dir / f"tight_head.png", bbox_inches='tight')
    plt.close()


def visualize_cross_attention_maps(attn, key_shape, filename_prefix="cross_attention_map"):
    """
    可视化并保存交叉注意力图。

    假设输入的注意力权重形状为：
      (batch_size, num_heads, query_len, key_len)

    对于交叉注意力可视化，每个query token（来自latents）会关注图像块token（keys），
    这些tokens的空间排列由key_shape给出（例如，对于32个token，可能为(4, 8)）。

    该函数首先对所有query token的注意力分布取平均，得到每个注意力头的一个大小为key_len的向量，
    然后将这个向量重塑为给定的空间网格，并为每个头保存一张图像。

    参数：
      - attn: torch.Tensor，形状为 (batch, heads, query_len, key_len)
      - key_shape: tuple (H, W)，表示key token的空间布局。
      - filename_prefix: 保存输出图像文件的前缀。
    """
    # import pdb;pdb.set_trace()
    # 选择第一个batch元素
    attn0 = attn[0]  # 形状: (num_heads, query_len, key_len)
    num_heads, query_len, key_len = attn0.shape

    if np.prod(key_shape) != key_len:
        raise ValueError(
            f"提供的 key_shape {key_shape} 与 key_len {key_len} 不匹配 (期望乘积为 {np.prod(key_shape)})。"
        )

    # 确保输出目录存在
    file = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = Path(f"/home/gdli7/Blade/results/pulid/attention_maps_v2/{file}")
    save_dir.mkdir(exist_ok=True, parents=True)

    # 对所有query tokens的注意力权重取平均，得到每个key的重要性向量，形状为 (num_heads, key_len)
    avg_attn = torch.mean(attn0.to(torch.float32), dim=1).detach().cpu().numpy()

    # 保存每个头的图像，其展示了在给定空间布局下key token的注意力分布
    for head in range(num_heads):
        head_attn = avg_attn[head]  # 形状: (key_len,)
        head_attn_img = head_attn.reshape(key_shape)
        plt.figure(figsize=(6, 6))
        plt.imshow(head_attn_img, cmap='inferno', aspect='auto')
        plt.colorbar()
        plt.title(f'Cross Attention Head {head}')
        plt.xlabel("Key Token X")
        plt.ylabel("Key Token Y")
        plt.savefig(save_dir / f"{filename_prefix}_head{head}.png", bbox_inches="tight")
        plt.close()


class PerceiverAttentionCAV12(nn.Module):
    def __init__(self, *, dim=3072, dim_head=128, heads=16, kv_dim=2048):
        super().__init__()
        self.dim = dim
        self.scale = dim_head ** -0.5
        self.dim_head = dim_head
        self.heads = heads
        self.inner_dim = dim_head * heads

        self.norm1 = nn.LayerNorm(dim if kv_dim is None else kv_dim)
        self.norm2 = nn.LayerNorm(dim)

        self.to_q = nn.Linear(dim, self.inner_dim, bias=False)
        self.to_kv = nn.Linear(dim if kv_dim is None else kv_dim, self.inner_dim * 2, bias=False)
        self.to_out = nn.Linear(self.inner_dim, dim, bias=False)

        # -----------------------------------------------------------------------------------
        # 对 latents 特征进行投影, 保证形状转换：(b, n2, dim) -> (b, n2, inner_dim)
        # self.latents_proj = nn.Linear(dim, self.inner_dim)

        self.dropout = nn.Dropout(p=0.5)
        self.attn_drop = nn.Dropout(p=0.5)
        # 添加保存标记
        self._attention_saved = False

        # gating --------------------------------------------------
        gating = False
        self.gating = gating
        # 动态 gating 模块：从 latent 特征中计算一个 gating 系数（范围在 0 到 1）
        if gating:
            self.gate_net = nn.Sequential(
                nn.Linear(dim, dim // 2),
                nn.ReLU(),
                nn.Linear(dim // 2, 1),
                nn.Sigmoid()
            )

    # def randn_projection(self, latents):
    #     """
    #     Compute a fixed random projection from 'dim' to 'inner_dim' inside each forward pass.
    #     Instead of storing the projection weights, we use a fixed seed with a local generator on CPU.
    #     latents shape: (b, n2, dim)
    #     Output shape: (b, n2, inner_dim)
    #     """
    #     # Create a new generator on CPU and set a fixed seed.
    #     generator = torch.Generator(device='cpu')
    #     generator.manual_seed(1234)  # Fixed seed for deterministic behavior
    #
    #     # Compute the fixed projection matrix on-the-fly on CPU.
    #     projection_matrix = torch.randn(self.dim, self.inner_dim, generator=generator) / math.sqrt(self.dim)
    #     # Convert the projection matrix to the same dtype as latents and move to the same device.
    #     projection_matrix = projection_matrix.to(latents.device, dtype=latents.dtype)
    #     return torch.matmul(latents, projection_matrix)
    #
    # def qr_projection(self, latents):
    #     """
    #     使用正交矩阵进行固定投影，从 'dim' 到 'inner_dim'。
    #     相比于直接用 randn 矩阵，这种方法能更好地保持 latents 原始数值信息，
    #     同时在不训练的情况下完成形状的变化。
    #
    #     latents shape: (b, n2, dim)
    #     Output shape: (b, n2, inner_dim)
    #     """
    #     # 创建一个随机矩阵，并进行QR分解使其正交
    #     # 首先在CPU上创建一个随机矩阵
    #     random_matrix = torch.randn(self.dim, self.inner_dim)
    #     # 对随机矩阵进行QR分解，取 Q 部分作为正交矩阵
    #     q, _ = torch.linalg.qr(random_matrix)
    #     # 若 dim > inner_dim，q 的形状将是 (dim, inner_dim)
    #     # 若 dim < inner_dim，需要采取其他策略（比如生成 (inner_dim, inner_dim) 然后取前 dim 行）
    #     projection_matrix = q
    #     # 将矩阵转换为与latents相同的设备和数据类型
    #     projection_matrix = projection_matrix.to(latents.device, dtype=latents.dtype)
    #     return torch.matmul(latents, projection_matrix)

    def fixed_projection(self, latents, projection):
        """
        将 latents 从 (b, n2, dim) 投影到 (b, n2, inner_dim) 的方法。
        根据 self.proj_method 的不同，可以采用不同的固定方法：
         - 'orthogonal': 利用QR分解构造正交矩阵
         - 'sparse': 利用稀疏随机矩阵（Achlioptas方法）
         - 'dct': 利用离散余弦变换（DCT），取前 inner_dim 个系数
        """
        generator = torch.Generator(device='cpu')
        generator.manual_seed(1234)  # Fixed seed for deterministic behavior
        if projection == 'randn':
            # 方法0：随机矩阵固定投影
            projection_matrix = torch.randn(self.dim, self.inner_dim, generator=generator) / math.sqrt(self.dim)
            # projection_matrix = torch.randn(self.dim, self.inner_dim) / math.sqrt(self.dim)
        elif projection == 'orthogonal':
            # 方法1：正交矩阵固定投影
            random_matrix = torch.randn(self.dim, self.inner_dim)
            q, _ = torch.linalg.qr(random_matrix)
            projection_matrix = q  # (dim, inner_dim)
        elif projection == 'sparse':
            # 方法2：稀疏随机投影
            # 根据 Achlioptas 的方法：
            # 每个元素取值：
            #   sqrt(3) with probability 1/6,
            #   0       with probability 2/3,
            #  -sqrt(3) with probability 1/6.
            prob = torch.rand(self.dim, self.inner_dim)
            projection_matrix = torch.zeros(self.dim, self.inner_dim)
            sqrt3 = math.sqrt(3)
            projection_matrix[prob < 1 / 6] = sqrt3
            projection_matrix[(prob >= 1 / 6) & (prob < 5 / 6)] = 0.0
            projection_matrix[prob >= 5 / 6] = -sqrt3
        elif projection == 'dct':
            # 方法3：基于离散余弦变换（DCT）的固定投影
            # 构造标准基函数，然后取前 inner_dim 个 DCT 基函数作为投影矩阵
            # 这里我们构造一个 (dim, dim) 的 DCT 矩阵，然后截取前 inner_dim 列
            # 注意：这里使用的 DCT-II 的定义，结果是确定性的
            device = latents.device
            # 构造 DCT 基矩阵
            n = self.dim
            dct_matrix = torch.zeros(n, n, device=device)
            for k in range(n):
                dct_matrix[:, k] = torch.cos(
                    math.pi * k * (torch.arange(n, device=device, dtype=torch.float32) + 0.5) / n)
            # 标准化
            dct_matrix = dct_matrix * math.sqrt(2 / n)
            dct_matrix[:, 0] = dct_matrix[:, 0] / math.sqrt(2)
            projection_matrix = dct_matrix[:, :self.inner_dim]
        else:
            projection_matrix = torch.randn(self.dim, self.inner_dim, generator=generator) / math.sqrt(self.dim)

        # 将 projection_matrix 转换到与 latents 相同的设备和 dtype
        projection_matrix = projection_matrix.to(latents.device, dtype=latents.dtype)
        return torch.matmul(latents, projection_matrix)

    def forward(self, x, latents, method='default', id_strength=1.0, q_strength=1.0, alpha=1.0, beta=1.0,
                attn_drop=False, projection="default"):
        """
        Args:
            x (torch.Tensor): image features
                shape (b, n1, D)
            latents (torch.Tensor): latent features
                shape (b, n2, D)
            method (str): the method to use ('default', 'weighted', 'dropout', 'self_attention')
            id_strength (float): factor to adjust the strength of latents
            q_strength (float): factor to adjust the strength of q
            alpha (float): weight for the output of attention mechanism
            beta (float): weight for the latents
        """
        # import pdb;pdb.set_trace()
        x = self.norm1(x) * id_strength  # x 1,32,2048 = node_data[embedding]
        latents = self.norm2(latents)  # 4,2304,3072 = img

        if projection == "default":
            latents_proj = self.fixed_projection(latents, projection)
        else:
            latents_proj = None

        b, seq_len, _ = latents.shape

        q = self.to_q(latents) * q_strength  # 4,2304,2048
        k, v = self.to_kv(x).chunk(2, dim=-1)  # 1,32,2048,chunk拆成两部分

        q = reshape_tensor(q, self.heads)  # 4,16,2304,128
        k = reshape_tensor(k, self.heads)  # 1,16,32,128
        v = reshape_tensor(v, self.heads)  # 1,16,32,128

        scale = 1 / math.sqrt(math.sqrt(self.dim_head))  # 0.2973
        weight = (q * scale) @ (k * scale).transpose(-2,
                                                     -1)  # More stable with f16 than dividing afterwards 4,16,2304,32
        weight = torch.softmax(weight.float(), dim=-1).type(weight.dtype)  # 4,16,2304,32

        # 保存第一个batch的注意力权重（仅第一次前向传播）
        visual = False
        if visual:
            if not self._attention_saved:
                # 1.-------------------------------
                # 假定key tokens构成图像网格。例如，如果有32个token，一个常见布局可能是(4, 8)。
                key_tokens = k.shape[2]
                # 示例网格：对于32个token，使用(4, 8)
                # 根据具体应用可修改此行代码
                key_shape = (4, 8)
                try:
                    visualize_cross_attention_maps(weight, key_shape, "perceiver_cross_attention")
                    self._attention_saved = True
                except Exception as e:
                    print(f"可视化交叉注意力时出错：{e}")

                # 2.----------------------------------------
                # save_attention_weights_as_image_v1(weight, "perceiver_attention")
                self._attention_saved = True

        # drop
        if attn_drop:
            weight = self.attn_drop(weight)  # QK img*id_cond

        out = weight @ v  # 1,16,32,128
        out = out.permute(0, 2, 1, 3).reshape(b, seq_len, -1)

        # 动态计算 gating 系数：这里采用对 latent 特征均值的方式计算一个标量 gating 系数
        if self.gating:
            # 这里计算的是每个样本的全局 latent 特征平均值，然后得到一个 gating 系数
            latent_mean = latents.mean(dim=1)  # 形状: (b, D)
            gate_val = self.gate_net(latent_mean)  # 形状: (b, 1)，取值范围 [0, 1]
            # 根据 gate_val 对 attention 输出进行加权
            # 你可以根据具体需求设计更复杂的融合方式，比如同时对 id 分支也进行处理后再组合
            out = gate_val.unsqueeze(1) * out

        # 根据不同融合方式进行处理
        if method == 'weighted' and latents_proj is not None:
            # 加权融合
            fused = alpha * out + beta * latents_proj
            return self.to_out(fused)
        elif method == 'dropout' and latents_proj is not None:
            # 使用 dropout 融合
            latents_dropped = self.dropout(latents_proj)
            fused = out + latents_dropped
            return self.to_out(fused)
        elif method == 'concat' and latents_proj is not None:
            # 拼接后通过线性映射融合
            fused = torch.cat([out, latents_proj], dim=-1)
            fused = (fused[..., :self.inner_dim] + fused[..., self.inner_dim:]) / 2.0
            return self.to_out(fused)
        elif method == 'residual' and latents_proj is not None:
            # 残差融合：ReLU( out + latents_proj )
            fused = torch.relu(out + latents_proj)
            return self.to_out(fused)
        elif method == 'sum' and latents_proj is not None:
            # 直接求和融合
            fused = out + latents_proj
            return self.to_out(fused)
        elif method == 'multiply' and latents_proj is not None:
            # 元素级乘法融合
            fused = out * latents_proj
            return self.to_out(fused)
        elif method == 'max' and latents_proj is not None:
            # 元素级取最大值融合
            fused = torch.max(out, latents_proj)
            return self.to_out(fused)
        elif method == 'weighted_fixed' and latents_proj is not None:
            # 固定权重的加权求和 (例如权重 0.3 与 0.7)
            fused = 0.3 * out + 0.7 * latents_proj
            return self.to_out(fused)
        elif method == 'cosine' and latents_proj is not None:
            # 基于归一化和余弦相似度计算融合权重
            eps = 1e-8
            out_norm = out / (torch.norm(out, p=2, dim=-1, keepdim=True) + eps)
            latents_proj_norm = latents_proj / (torch.norm(latents_proj, p=2, dim=-1, keepdim=True) + eps)
            sim = (out_norm * latents_proj_norm).sum(dim=-1, keepdim=True)
            weight = (sim + 1) / 2  # 将余弦相似度映射到 [0, 1]
            fused = weight * out + (1 - weight) * latents_proj
            return self.to_out(fused)
        else:
            # 默认直接输出 attention 结果
            return self.to_out(out)


class PerceiverAttention(nn.Module):
    def __init__(self, *, dim, dim_head=64, heads=8, kv_dim=None):
        super().__init__()
        self.scale = dim_head ** -0.5
        self.dim_head = dim_head
        self.heads = heads
        inner_dim = dim_head * heads

        self.norm1 = nn.LayerNorm(dim if kv_dim is None else kv_dim)
        self.norm2 = nn.LayerNorm(dim)

        self.to_q = nn.Linear(dim, inner_dim, bias=False)
        self.to_kv = nn.Linear(dim if kv_dim is None else kv_dim, inner_dim * 2, bias=False)
        self.to_out = nn.Linear(inner_dim, dim, bias=False)

    def forward(self, x, latents):
        """
        Args:
            x (torch.Tensor): image features
                shape (b, n1, D)
            latent (torch.Tensor): latent features
                shape (b, n2, D)
        """
        x = self.norm1(x)
        latents = self.norm2(latents)

        b, seq_len, _ = latents.shape

        q = self.to_q(latents)
        kv_input = torch.cat((x, latents), dim=-2)
        k, v = self.to_kv(kv_input).chunk(2, dim=-1)

        q = reshape_tensor(q, self.heads)
        k = reshape_tensor(k, self.heads)
        v = reshape_tensor(v, self.heads)

        # attention
        scale = 1 / math.sqrt(math.sqrt(self.dim_head))
        weight = (q * scale) @ (k * scale).transpose(-2, -1)  # More stable with f16 than dividing afterwards
        weight = torch.softmax(weight.float(), dim=-1).type(weight.dtype)
        out = weight @ v

        out = out.permute(0, 2, 1, 3).reshape(b, seq_len, -1)

        return self.to_out(out)


class IDFormer(nn.Module):
    """
    - perceiver resampler like arch (compared with previous MLP-like arch)
    - we concat id embedding (generated by arcface) and query tokens as latents
    - latents will attend each other and interact with vit features through cross-attention
    - vit features are multi-scaled and inserted into IDFormer in order, currently, each scale corresponds to two
      IDFormer layers
    """

    def __init__(
            self,
            dim=1024,
            depth=10,
            dim_head=64,
            heads=16,
            num_id_token=5,
            num_queries=32,
            output_dim=2048,
            ff_mult=4,
    ):
        super().__init__()

        self.num_id_token = num_id_token
        self.dim = dim
        self.num_queries = num_queries
        assert depth % 5 == 0
        self.depth = depth // 5
        scale = dim ** -0.5

        self.latents = nn.Parameter(torch.randn(1, num_queries, dim) * scale)
        self.proj_out = nn.Parameter(scale * torch.randn(dim, output_dim))

        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(
                nn.ModuleList(
                    [
                        PerceiverAttention(dim=dim, dim_head=dim_head, heads=heads),
                        FeedForward(dim=dim, mult=ff_mult),
                    ]
                )
            )

        for i in range(5):
            setattr(
                self,
                f'mapping_{i}',
                nn.Sequential(
                    nn.Linear(1024, 1024),
                    nn.LayerNorm(1024),
                    nn.LeakyReLU(),
                    nn.Linear(1024, 1024),
                    nn.LayerNorm(1024),
                    nn.LeakyReLU(),
                    nn.Linear(1024, dim),
                ),
            )

        self.id_embedding_mapping = nn.Sequential(
            nn.Linear(1280, 1024),
            nn.LayerNorm(1024),
            nn.LeakyReLU(),
            nn.Linear(1024, 1024),
            nn.LayerNorm(1024),
            nn.LeakyReLU(),
            nn.Linear(1024, dim * num_id_token),
        )

    def forward(self, x, y):

        latents = self.latents.repeat(x.size(0), 1, 1)

        x = self.id_embedding_mapping(x)
        x = x.reshape(-1, self.num_id_token, self.dim)

        latents = torch.cat((latents, x), dim=1)

        for i in range(5):
            vit_feature = getattr(self, f'mapping_{i}')(y[i])
            ctx_feature = torch.cat((x, vit_feature), dim=1)
            for attn, ff in self.layers[i * self.depth: (i + 1) * self.depth]:
                latents = attn(ctx_feature, latents) + latents
                latents = ff(latents) + latents

        latents = latents[:, :self.num_queries]
        latents = latents @ self.proj_out
        return latents
