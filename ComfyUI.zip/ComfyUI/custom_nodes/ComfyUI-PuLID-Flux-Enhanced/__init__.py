from .pulidflux import PulidFluxEvaClipLoader, PulidFluxInsightFaceLoader
from .pulidflux_v1 import ApplyPulidFlux, PulidFluxModelLoader
from .pulidflux_v12 import ApplyPulidFluxV12, PulidFluxModelLoaderV12

NODE_CLASS_MAPPINGS = {
    "PulidFluxModelLoader": PulidFluxModelLoader,
    "PulidFluxModelLoaderV12": PulidFluxModelLoaderV12,
    "PulidFluxInsightFaceLoader": PulidFluxInsightFaceLoader,
    "PulidFluxEvaClipLoader": PulidFluxEvaClipLoader,
    "ApplyPulidFlux": ApplyPulidFlux,
    "ApplyPulidFluxV12": ApplyPulidFluxV12,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "PulidFluxInsightFaceLoader": "Load InsightFace (PuLID Flux)",
    "PulidFluxEvaClipLoader": "Load Eva Clip (PuLID Flux)",

    "PulidFluxModelLoader": "Load PuLID Flux Model",
    "PulidFluxModelLoaderV12": "load PuLID Flux Model V12",

    "ApplyPulidFlux": "Apply PuLID Flux",
    "ApplyPulidFluxV12": "Apply Pulid Flux V12"
}

__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']
